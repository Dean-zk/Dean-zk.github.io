﻿
using var game = new SpaceShooter.Game1();
game.Run();
