// GameManager class

using System.Collections.Generic;

namespace SpaceShooter
{
    public enum GameResult //enum game states
    {
        None,
        Win,
        Lose
    }

    internal class GameManager
    {
        public int score;
        public bool shouldRemove;
        public bool destroyAngreeh;
        public bool gameStarted;
        public bool playerAlive = true;
        public bool drawInitialText = true;
        public bool resetGame = false;
        public GameResult GameResult { get; private set; } = GameResult.None;
        public SpriteFont textFont;

        public void UpdateScore() //update score.
        {
            if (destroyAngreeh)
            {
                score++;
                destroyAngreeh = false;
            }
        }

        public void ConditionChecker() //manage gamestate by if statements.
        {
            if (score >= 40 && playerAlive)
            {
                resetGame = true;
                gameStarted = false;
                GameResult = GameResult.Win;
            }
            else if (score < 40 && !playerAlive)
            {
                resetGame = true;
                gameStarted = false;
                GameResult = GameResult.Lose;
            }
        }

        public void DrawText(SpriteBatch spriteBatch)
        {
            if (drawInitialText)
            {
                GameState(spriteBatch);
            }
            else if (gameStarted && GameResult == GameResult.None) //Draw score if game is running
            {
                spriteBatch.DrawString(
                    textFont,
                    $"Score: {score}",
                    new Vector2(10, 10),
                    Color.White
                );
            }
        }
        public void StartGame() //start game succesfully
        {
            KeyboardState _kbState = Keyboard.GetState();

            if (_kbState.IsKeyDown(Keys.Enter))
            {
                gameStarted = true;
                drawInitialText = false;
                GameResult = GameResult.None;
            }
        }

        public void Destroy(List<GameObject> objList, GameObject obj) //if item is not valid anymore then delete it.
        {
            if (shouldRemove)
            {
                objList.Remove(obj);
            }
        }

        private void GameState(SpriteBatch spriteBatch) //what text should be printed in what state
        {
            switch (GameResult)
            {
                case GameResult.Win:
                    spriteBatch.DrawString(
                        textFont,
                        "You won the game!\nPress enter to play again or esc to leave.",
                        new Vector2(100, 200),
                        Color.White
                    );
                    break;

                case GameResult.Lose:
                    spriteBatch.DrawString(
                        textFont,
                        "Looks like you died my friend!\nPress enter to play again or esc to leave.",
                        new Vector2(100, 200),
                        Color.White
                    );
                    break;

                default:
                    spriteBatch.DrawString(
                        textFont,
                        "Welcome to\n\n -A space game with no engine-\n\n Kill 40 ships to win!\n\n Move with A & D and fire with SPACE.\n\nPress enter to start and esc to exit.",
                        new Vector2(100, 200),
                        Color.White
                    );
                    break;
            }
        }
    }
}
