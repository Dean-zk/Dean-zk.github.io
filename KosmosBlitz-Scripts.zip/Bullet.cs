﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace SpaceShooter
{
    internal class Bullet : GameObject
    {
        private KeyboardState _kbState;

        private bool isActive = false;
        private float bulletSpeed = 650;
        private readonly float fireDelay = 0.7f;

        private TimeSpan elapsedTime;
        private TimeSpan lastShotTime = TimeSpan.Zero;

        private Rectangle _bulletRect;
        private Texture2D bulletTexture;
        private Vector2 bulletPos;
        public Vector2 tempPos;
        private GameManager gameManager;

        private List<Bullet> bulletLs = new List<Bullet>(); //list for the bullets and the enemy's
        private List<Angreeh> angreehLs = new List<Angreeh>();

        public Bullet(
            Texture2D pBulletTexture,
            Vector2 pBulletPos,
            GraphicsDeviceManager pGraphics,
            List<Angreeh> pAngreehList,
            GameManager pGameManager
        )
            : base(pBulletTexture, pBulletPos, pGraphics)
        {
            this.bulletTexture = pBulletTexture;
            this.bulletPos = pBulletPos;
            _graphics = pGraphics;
            angreehLs = pAngreehList;
            gameManager = pGameManager;

            _bulletRect = new Rectangle(
                (int)(pBulletPos.X - bulletTexture.Width / 2),
                (int)(pBulletPos.Y - bulletTexture.Height / 2),
                bulletTexture.Width,
                bulletTexture.Height
            );
        }

        public override void Update(GameTime gameTime)
        {
            FireBullet(gameTime);
            BulletCollision();
        }

        public override void Draw(SpriteBatch _spriteBatch)
        {
            BulletListLoop(_spriteBatch);
        }

        private void FireBullet(GameTime gameTime)
        {
            _kbState = Keyboard.GetState();
            elapsedTime = gameTime.TotalGameTime - lastShotTime;

            if (_kbState.IsKeyDown(Keys.Space) && elapsedTime.TotalSeconds >= fireDelay) //added a delay so the game has a little more of a challange to it.
            {
                Bullet newBullet = new Bullet(
                    bulletTexture,
                    tempPos,
                    _graphics,
                    angreehLs,
                    gameManager
                );
                newBullet.isActive = true;
                bulletLs.Add(newBullet);

                lastShotTime = gameTime.TotalGameTime;
            }

            UpdateBullet(gameTime);
        }

        public void DrawBullet(SpriteBatch _spriteBatch)
        {
            if (isActive)
            {
                _spriteBatch.Draw(
                    bulletTexture,
                    bulletPos,
                    null,
                    Color.White,
                    0f,
                    new Vector2(bulletTexture.Width / 2, bulletTexture.Height / 2),
                    Vector2.One,
                    SpriteEffects.None,
                    0f
                );
            }
        }

        public void BulletListLoop(SpriteBatch spriteBatch)
        {
            foreach (Bullet i in bulletLs)
            {
                i.DrawBullet(spriteBatch); //because im working with multiple bullets i update the ones in the list based on index.
            }
        }

        private void MoveBullets(GameTime gameTime)
        {
            if (isActive)
            {
                bulletPos.Y -= bulletSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds; //how fast it wil move.
            }
        }

        private void UpdateBullet(GameTime gameTime) //here i update the bullets and the rectangle.
        {
            for (int i = 0; i < bulletLs.Count; i++)
            {
                bulletLs[i].MoveBullets(gameTime);
                bulletLs[i].UpdateRectangle();

                if (bulletLs[i].bulletPos.Y < 0)
                {
                    bulletLs.RemoveAt(i); //if a bullet needs to be removed i skip over an index to make sure i do not read an empty entry.
                    i--;
                }
            }
        }

        private void UpdateRectangle()
        {
            _bulletRect.X = (int)(bulletPos.X - bulletTexture.Width / 2);
            _bulletRect.Y = (int)(bulletPos.Y - bulletTexture.Height / 2);
        }

        private void BulletCollision() //check for collision between the angreeh and the bullet.
        {
            for (int i = angreehLs.Count - 1; i >= 0; i--)
            {
                for (int j = bulletLs.Count - 1; j >= 0; j--)
                {
                    if (bulletLs[j]._bulletRect.Intersects(angreehLs[i]._enemyRect))
                    {
                        gameManager.score += 1;
                        angreehLs.RemoveAt(i);
                        bulletLs.RemoveAt(j);
                        break;
                    }
                }
            }
        }
    }
}
