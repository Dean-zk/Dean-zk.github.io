﻿global using System;
global using static System.Console;
global using Microsoft.Xna.Framework;
global using Microsoft.Xna.Framework.Graphics;
global using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace SpaceShooter
{
    public class Game1 : Game
    {
        private List<GameObject> gameObjList = new List<GameObject>();
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Texture2D shipTexture;
        private Vector2 shipPos;
        Texture2D bulletTexture;
        Vector2 bulletPos;
        Vector2 enemyPos;

        GameManager manager;
        SpaceShip spaceShip;
        Bullet bullet;
        Angreeh angreeh;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            FullScreen();
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            shipPos = new Vector2(
                _graphics.PreferredBackBufferWidth / 2,
                _graphics.PreferredBackBufferHeight - 200
            );
            enemyPos = new Vector2(
                _graphics.PreferredBackBufferWidth / 2,
                _graphics.PreferredBackBufferHeight - 1000
            );
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            shipTexture = Content.Load<Texture2D>("Shippy");
            bulletTexture = Content.Load<Texture2D>("Star");

            // TODO: use this.Content to load your game content here
            manager = new GameManager();
            manager.textFont = Content.Load<SpriteFont>("text"); // sprite font to display text.
            angreeh = new Angreeh(shipTexture, enemyPos, _graphics);
            bullet = new Bullet(bulletTexture, bulletPos, _graphics, angreeh.angreehLs, manager); // giving the list of angreehs so I can check for collision per index
            spaceShip = new SpaceShip(shipTexture, shipPos, _graphics, angreeh.angreehLs, manager);

            gameObjList.Add(bullet); // add all the objects to a list to update them at the same time.
            gameObjList.Add(spaceShip);
            gameObjList.Add(angreeh);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            GameRunner(gameTime, _spriteBatch); // Kind of messy but here is the function I call to update all game objects at once

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.DarkSlateGray); // background color.

            // TODO: Add your drawing code here
            _spriteBatch.Begin(); // draw everything at once.
            manager.DrawText(_spriteBatch);
            for (int i = 0; i < gameObjList.Count; i++)
            {
                gameObjList[i].Draw(_spriteBatch); // Get the index and call the draw function from that list entry.
            }
            _spriteBatch.End();

            base.Draw(gameTime);
        }

        private void FullScreen()
        {
            Content.RootDirectory = "Content";
            IsMouseVisible = false;

            _graphics.PreferredBackBufferWidth = GraphicsAdapter
                .DefaultAdapter
                .CurrentDisplayMode
                .Width;
            _graphics.PreferredBackBufferHeight = GraphicsAdapter
                .DefaultAdapter
                .CurrentDisplayMode
                .Height;

            _graphics.IsFullScreen = true;

            _graphics.HardwareModeSwitch = true;

            _graphics.ApplyChanges();
        }

        private void GameRunner(GameTime gameTime, SpriteBatch _spriteBatch)
        {
            manager.StartGame();
            if (manager.gameStarted)
            {
                bullet.tempPos = spaceShip.shipPos;
                for (int i = 0; i < gameObjList.Count; i++)
                {
                    gameObjList[i].Update(gameTime);
                }
                manager.Destroy(gameObjList, spaceShip);
                manager.UpdateScore();             }

            _spriteBatch.Begin();

            manager.ConditionChecker();

            _spriteBatch.End();

            if (manager.resetGame || !manager.playerAlive)
            {
                ResetGame();
            }
        }

        private void ResetGame() //reset all stats to zero or null to run the game again
        {
            gameObjList.Clear();
            shipPos = new Vector2(
                _graphics.PreferredBackBufferWidth / 2,
                _graphics.PreferredBackBufferHeight - 200
            );
            enemyPos = new Vector2(
                _graphics.PreferredBackBufferWidth / 2,
                _graphics.PreferredBackBufferHeight - 1000
            );

            angreeh = new Angreeh(shipTexture, enemyPos, _graphics);
            bullet = new Bullet(bulletTexture, bulletPos, _graphics, angreeh.angreehLs, manager);
            spaceShip = new SpaceShip(shipTexture, shipPos, _graphics, angreeh.angreehLs, manager);

            gameObjList.Add(bullet);
            gameObjList.Add(spaceShip);
            gameObjList.Add(angreeh);

            manager.score = 0;
            manager.shouldRemove = false;
            manager.destroyAngreeh = false;
            manager.gameStarted = false;
            manager.playerAlive = true;
            manager.resetGame = false;
            manager.drawInitialText = true;
        }
    }
}