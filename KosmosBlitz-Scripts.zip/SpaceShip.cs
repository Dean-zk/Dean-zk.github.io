﻿using System.Collections.Generic;

namespace SpaceShooter
{
    internal class SpaceShip : GameObject
    {
        private Rectangle _shipRect;
        public Vector2 shipPos;
        private Texture2D shipTexture;

        private float shipSpeed = 750;
        private List<Angreeh> angreehLs = new List<Angreeh>();
        GameManager manager;

        //Constructer for the spaceship. Also a base constructer from the gameobject class to create the objects succesfully
        public SpaceShip(
            Texture2D pShipTexture,
            Vector2 pShipPos,
            GraphicsDeviceManager pGraphics,
            List<Angreeh> pAngreehList,
            GameManager pManager
        )
            : base(pShipTexture, pShipPos, pGraphics)
        { //creating everything needed for the ship including the rectangle for collision.
            shipTexture = pShipTexture;
            shipPos = pShipPos;
            _graphics = pGraphics;
            angreehLs = pAngreehList;
            manager = pManager;

            _shipRect = new Rectangle(
                (int)(pShipPos.X - shipTexture.Width / 2),
                (int)(pShipPos.Y - shipTexture.Height / 2),
                shipTexture.Width,
                shipTexture.Height
            );
        }

        /// <summary>
        /// Update method for this object. All from the gameobject class.
        /// </summary>
        public override void Update(GameTime gameTime) 
        {
            if (!manager.shouldRemove)
            {
                UpdateShipMovement(gameTime);
                UpdateRectangle();
                ShipCollisionCheck();
            }
        }

        /// <summary>
        /// Universal drawing method
        /// </summary>
        public override void Draw(SpriteBatch _spriteBatch)
        {
            DrawShip(_spriteBatch);
        }

        /// <summary>
        /// Update the movement based on input
        /// </summary>
        /// <param name="gameTime"></param>
        public void UpdateShipMovement(GameTime gameTime)
        {
            KeyboardState _kbState = Keyboard.GetState();

            if (_kbState.IsKeyDown(Keys.A))
            {
                shipPos.X -= shipSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            }
            else if (_kbState.IsKeyDown(Keys.D))
            {
                shipPos.X += shipSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            }
        }

        /// <summary>
        /// create the ship texture and draw it
        /// </summary>
        public void DrawShip(SpriteBatch _spriteBatch)
        {
            _spriteBatch.Draw(
                shipTexture,
                shipPos,
                null,
                Color.White,
                0f,
                new Vector2(shipTexture.Width / 2, shipTexture.Height / 2),
                Vector2.One,
                SpriteEffects.FlipVertically,
                0f
            );
        }

        /// <summary>
        /// Every frame I update the rectangle so that the collision will always work.
        /// </summary>
        private void UpdateRectangle()
        {
            _shipRect.X = (int)(shipPos.X - shipTexture.Width / 2);
            _shipRect.Y = (int)(shipPos.Y - shipTexture.Height / 2);

            if (_shipRect.Right > _graphics.PreferredBackBufferWidth)
            {
                shipPos.X = _graphics.PreferredBackBufferWidth - shipTexture.Width / 2;
            }
            else if (_shipRect.Left < 0)
            {
                shipPos.X = shipTexture.Width / 2;
            }
        }

        /// <summary>
        /// For each angreeh that is created in the game i loop over its list to check for collision
        /// </summary>
        private void ShipCollisionCheck()
        {
            foreach (Angreeh angreeh in angreehLs)
            {
                if (_shipRect.Intersects(angreeh._enemyRect))
                {
                    manager.shouldRemove = true;
                    manager.playerAlive = false;
                    break;
                }
            }
        }
    }
}
