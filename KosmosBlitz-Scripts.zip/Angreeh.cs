﻿using System.Collections.Generic;

namespace SpaceShooter
{
    internal class Angreeh : GameObject
    {
        public List<Angreeh> angreehLs = new List<Angreeh>();
        public Rectangle _enemyRect;
        protected Vector2 enemyPos;
        protected Texture2D enemyTexture;
        private float enemySpeed = 600;
        Random randomX = new Random();
        Angreeh angreeh;
        private float spawnDelay = 0.7f;
        bool isActive = false;

        TimeSpan elapsedTime;
        private TimeSpan lastShotTime = TimeSpan.Zero;
        GameManager manager = new GameManager();

        public Angreeh(Texture2D pEnemyTexture, Vector2 pEnemyPos, GraphicsDeviceManager pGraphics)
            : base(pEnemyTexture, Vector2.Zero, pGraphics)
        {
            enemyPos = pEnemyPos;
            enemyTexture = pEnemyTexture;
            _graphics = pGraphics;

            // Set initial position to a random position on the top of the screen
            enemyPos = new Vector2(randomX.Next(_graphics.PreferredBackBufferWidth), 50);

            _enemyRect = new Rectangle(
                (int)(enemyPos.X - enemyTexture.Width / 2),
                (int)(enemyPos.Y - enemyTexture.Height / 2),
                enemyTexture.Width,
                enemyTexture.Height
            );
        }

        //almost all the logic here is the exact same as the bullet class.
        public override void Draw(SpriteBatch _spriteBatch)
        {
            AngreehListLoop(_spriteBatch);
        }

        public override void Update(GameTime _gameTime)
        {
            SpawnAngreeh(_gameTime);
        }

        public void DrawEnemy(SpriteBatch _spriteBatch)
        {
            _spriteBatch.Draw(
                enemyTexture,
                enemyPos,
                null,
                Color.Red,
                0f,
                new Vector2(enemyTexture.Width / 2, enemyTexture.Height / 2),
                Vector2.One,
                SpriteEffects.None,
                0f
            );
        }

        public void AngreehListLoop(SpriteBatch spriteBatch)
        {
            foreach (Angreeh i in angreehLs)
            {
                i.DrawEnemy(spriteBatch);
            }
        }

        private void SpawnAngreeh(GameTime gameTime)
        {
            elapsedTime = gameTime.TotalGameTime - lastShotTime;
            if (elapsedTime.TotalSeconds >= spawnDelay)
            {
                angreeh = new Angreeh(enemyTexture, enemyPos, _graphics);
                angreehLs.Add(angreeh);
                angreeh.isActive = true;

                lastShotTime = gameTime.TotalGameTime;
            }

            UpdateEnemy(gameTime);
        }

        private void UpdateEnemy(GameTime _gameTime)
        {
            for (int i = 0; i < angreehLs.Count; i++)
            {
                angreehLs[i].MoveAngreeh(_gameTime);
                angreehLs[i].UpdateRectangle();

                if (angreehLs[i].enemyPos.Y < 0)
                {
                    angreehLs.RemoveAt(i);
                    i--;
                }
            }
        }

        private void MoveAngreeh(GameTime _gameTime)
        {
            if (isActive)
            {
                enemyPos.Y += enemySpeed * (float)_gameTime.ElapsedGameTime.TotalSeconds;
            }
        }

        private void UpdateRectangle()
        {
            _enemyRect.X = (int)(enemyPos.X - enemyTexture.Width / 2);
            _enemyRect.Y = (int)(enemyPos.Y - enemyTexture.Height / 2);
        }
    }
}
